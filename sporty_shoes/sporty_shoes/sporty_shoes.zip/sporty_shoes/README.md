# Sporty_Shoes
An E-commerce application with spring boot

Google Auth credentials in app.properties are dummy credentials

